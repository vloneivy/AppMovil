import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-misdatos',
  templateUrl: './misdatos.component.html',
  styleUrls: ['./misdatos.component.scss'],
})
export class MisdatosComponent  implements OnInit {

  constructor() { }

  ngOnInit() {}

}
