import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-miclase',
  templateUrl: './miclase.component.html',
  styleUrls: ['./miclase.component.scss'],
})
export class MiclaseComponent  implements OnInit {

  constructor() { }

  ngOnInit() {}

}
